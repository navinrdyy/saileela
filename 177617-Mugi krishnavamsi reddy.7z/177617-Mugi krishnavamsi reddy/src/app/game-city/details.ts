export interface IDetails{
    gameId:number,
    gameName:string,
    gamePrice:number
}