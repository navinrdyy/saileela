import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {IDetails} from './game-city/details';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class GameserviceService {

  private _url: string = "assets/data/GameList.json";

  constructor(private http: HttpClient) { }

  getDetails(): Observable<IDetails[]>{

    return this.http.get<IDetails[]>(this._url);
  }
}
