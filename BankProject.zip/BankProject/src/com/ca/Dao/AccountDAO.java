package com.ca.Dao;

import java.util.HashMap;

import com.ca.entity.Account;

public interface AccountDAO {

	public int addcustomer(Integer b,Account a);
	 public Account showbalance(int acc);
}
