package com.ca.Dao;

import java.util.HashMap;

import com.ca.entity.Account;
import com.ca.util.Collection;

public class AccountDAOImpl implements AccountDAO {

	
	@Override
	public int addcustomer(Integer b,Account a) {
		Collection.addcustomer(b,a);
		return 0;
	}
	@Override
	public Account showbalance(int acc) {
		Account a=Collection.showbalance(acc);
		return a;
	}

	
	
}
