package com.ca.Service;

import java.util.HashMap;

import com.ca.entity.Account;
public interface AccountService {

	public int addcustomer(Integer a,Account a2);
	public Account showbalance(int acc);
	public boolean validateCustomerName(String name);
	public boolean ValidateCustomerMobileno(String cid);
	 public boolean ValidateBranch(String name);
	
	 
	
	
}
