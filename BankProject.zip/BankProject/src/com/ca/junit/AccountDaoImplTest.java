package com.ca.junit;

import org.junit.Assert;
import org.junit.Test;

import com.ca.Dao.AccountDAO;
import com.ca.Dao.AccountDAOImpl;
import com.ca.Exception.InvalidDataException;
import com.ca.entity.Account;


public class AccountDaoImplTest {

	static AccountDAO accdao=new AccountDAOImpl();
	
	@Test
	public static void Addcustomer() throws InvalidDataException
	{
		Assert.assertEquals(1234,accdao.addcustomer(1234, new Account("YASH", "MIPL", "9840502059", 50000.00)));
	}
	
}
