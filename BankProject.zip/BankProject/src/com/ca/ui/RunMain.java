package com.ca.ui;

import java.util.Random;
import java.util.Scanner;

import com.ca.Exception.InvalidDataException;
import com.ca.Service.AccountService;
import com.ca.Service.AccountServiceImpl;
import com.ca.entity.Account;
public class RunMain {

	static Scanner sc=null;
	static AccountService as=null;
	public static void main(String[] args) {
		sc=new Scanner(System.in);
		as=new AccountServiceImpl();
		while(true)
		{
			System.out.println(" ");
			System.out.println("$****************$");
		System.out.println("Enter The Menu");
		System.out.println("1) To create An Account");
		System.out.println("2) To Show Balance ");
		System.out.println("3) To Deposit");
		System.out.println("4) To Withdraw");
		System.out.println("5) Fund Transfer");
		System.out.println("6) Print Transaction");
		int a=0;
		a=sc.nextInt();
		switch(a)
		{
		case 1:
			addcustomer();
			break;
		case 2:
			showbalance();
			break;
		case 3:
				deposit();	
			break;
		case 4:
			withdraw();
			break;
		case 5:
			fundtransfer();
			break;
		case 6:
			printtransaction();
			break;
		case 7:
			default:
		}	
	}}
	public static void addcustomer()
	{
		
		Random ran=new Random();
		int accno=ran.nextInt(2000);
		System.out.println("Enter The Customer Name");
		String name=sc.next();
		boolean res1=as.validateCustomerName(name);
		try
		{
			if(res1==false)
			{
				throw new InvalidDataException("Invalid");
				}
				else {
					System.out.println("Continue");
				}
			{
		System.out.println("Enter The Branch");
		String branch=sc.next();
		boolean res2=as.ValidateBranch(branch);
		try
		{	
			if(res2==false)
			{
				throw new InvalidDataException("Invalid");
				}
				else {
					System.out.println("Continue");
				}
				{
		System.out.println("Enter The Mobile No");
		String mobile=sc.next();
		boolean res3=as.ValidateCustomerMobileno(mobile);
		try
		{
			if(res3==false)
			{
				throw new InvalidDataException("Invalid");
				}
				else {
					System.out.println("Continue");
				}	
			{
		System.out.println("Enter The Account Balance");
		Double balance=sc.nextDouble();
		Account a=new Account(name, branch, mobile, balance);
		as.addcustomer(accno,a);
		System.out.println("****************************");
		System.out.println("CREATED Successfully");
		System.out.println("Name: " +name);
		System.out.println("Branch: "+branch);
		System.out.println("Mobile No: "+mobile);
		System.out.println("Account number: " +accno);
		}}
		catch(Exception e)
		{
		System.out.println("Enter The Valid Name: "+e);
		}}}	
			catch (Exception e)
		{
				System.out.println("Enter The Valid Branch: "+e);	
		}			}	
		}
		catch (Exception e)
		{
			System.out.println("Enter The Valid Mobile No: "+e);
		}}
	public static void showbalance() 
	{	
		System.out.println("Enter Your Account Number To Get The Balance");
		int acc=sc.nextInt();
	Account a=as.showbalance(acc);
	System.out.println(a.getCustomerName()+ " Your Account Balance Is: "+a.getBalance());
	}
		public static void deposit()
		{
			System.out.println("Enter Your Account Number To Deposit");
			int acc=sc.nextInt();
			Account a=as.showbalance(acc);
			double d=a.getBalance();
			System.out.println("Your Account Balance is: "+d);
			System.out.println("Enter The Amount To Deposit");
			double amt=sc.nextDouble();
			double res=a.setBalance(d+amt);
			System.out.println("Account Balance is: "+res);	
		}
		public static void withdraw()
		{
			System.out.println("Enter Your Account Number To Withdraw");
			int acc=sc.nextInt();
			Account a=as.showbalance(acc);
			double d=a.getBalance();
			System.out.println("Your Account Balance is: "+d);
			System.out.println("Enter The Amount To Withdraw");
			double wa=sc.nextDouble();
			if(d>wa)
			{
				double res=a.setBalance(d-wa);
				System.out.println("Account Balance is: "+res);
			}
			else {
				System.out.println("Need To Deposit More Money");
			}
			}
		public static void fundtransfer()
		{
		System.out.println("Enter the Account No To Transfer The Fund");
		int acc1=sc.nextInt();
		Account a=as.showbalance(acc1);
		System.out.println(a.getBalance());
		System.out.println("Enter The Amount");
		double w=sc.nextDouble();
		double res=a.getBalance()-w;
		System.out.println("Amount Has Been Debited ");
		System.out.println("Account Balance is: "+res);
		System.out.println("Enter the Account No To Receive The Fund");
		int acc2=sc.nextInt();
		Account a1=as.showbalance(acc2);
		System.out.println(a1.getBalance());
		double res2=a1.getBalance()+w;
		System.out.println("Amount Has Been Credited " );
		System.out.println("Account Balance is: "+res2);
		}
		public static void printtransaction()
		{
			fundtransfer();
		}
}
