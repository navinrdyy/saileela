package com.ca.util;

import java.util.HashMap;

import com.ca.entity.Account;

public class Collection {

	static HashMap<Integer, Account> hs=null;
	static {
		hs=new HashMap<Integer, Account>();
		hs.put(1234, new Account("YASH", "MIPL", "9840502059", 50000.00));
		hs.put(5678, new Account("SP", "TRC", "9840502069", 60000.00));
		hs.put(8765, new Account("THARUN", "SIPCOT", "9840502079", 70000.00));
		hs.put(4321, new Account("SANGEETH", "HOME", "9840502089", 80000.00));
		
	}
	public static void addcustomer(Integer b,Account a)
	{
		hs.put(b, a); 
	}
	public static void  deleteCustomer(int accno)
	{
		hs.remove(accno);
	}
	public static Account showbalance(int acc)
	{
		if(hs.containsKey(acc))
		{
			Account a=hs.get(acc);
			return a;
		}
		else
			return null;
	}
}
