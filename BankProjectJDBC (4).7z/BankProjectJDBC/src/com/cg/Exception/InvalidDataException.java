package com.cg.Exception;

public class InvalidDataException extends Exception{

	public InvalidDataException(String arg0) {
		super(arg0);
		
	}
}
