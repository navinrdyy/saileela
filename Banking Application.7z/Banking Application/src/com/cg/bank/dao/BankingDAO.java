package com.cg.bank.dao;

import java.util.HashMap;

import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;
import com.cg.bank.exception.BankException;

public interface BankingDAO {
	
public HashMap <Long,Customer>createAccount(Account a, Customer c) throws BankException;
public double showBalance(long accountNo);
public double deposit(long accountNo);
public double withdraw(long accountNo);
public double fundTransfer(long accountNo);
public void printTransaction();
public HashMap<Long, Account> add(Account b);
}
