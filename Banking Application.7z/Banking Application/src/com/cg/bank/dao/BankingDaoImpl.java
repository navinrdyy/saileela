package com.cg.bank.dao;

import java.util.HashMap;

import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;
import com.cg.bank.exception.BankException;
import com.cg.bank.util.Bank_Entry;

public class BankingDaoImpl implements BankingDAO {

	public HashMap <Long,Customer>createAccount(Account a, Customer c) throws BankException{
HashMap<Long,Customer> hc= Bank_Entry.createAccount(a,c);
return hc;
}

	@Override
	public double showBalance(long accountNo) {
		double d= Bank_Entry.showBalance(accountNo);
		return d;
	}

	@Override
	public double deposit(long accountNo) {
		double d= Bank_Entry.showBalance(accountNo);
		return d;
	}

	@Override
	public double withdraw(long accountNo) {
		double d= Bank_Entry.showBalance(accountNo);
		return d;
	}

	@Override
	public double fundTransfer(long accountNo) {
		double d= Bank_Entry.showBalance(accountNo);
		return d;
	}

	@Override
	public void printTransaction() {
		
		// TODO Auto-generated method stub

	}

	public Account getaccountdetails(long accountnumber) {
		// TODO Auto-generated method stub
		Account b=Bank_Entry.getaccountdetails(accountnumber);
		return b;
	}

	public  HashMap<Long, Account> add(Account b) {
		// TODO Auto-generated method stub
		HashMap<Long, Account> bh=Bank_Entry.add(b);
		return bh;
	}

}
