package com.cg.bank.entity;

public class Account {

	private long accountNo;
	private String ifsc;
	private String branch;
	private String accountType;
	private double balance;
	
	public Account(long accountNo, String ifsc, String branch, String accountType, double balance) {
		super();
		this.accountNo = accountNo;
		this.ifsc = ifsc;
		this.branch = branch;
		this.accountType = accountType;
		this.balance = balance;
	}
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	public String getIfsc() {
		return ifsc;
	}
	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", ifsc=" + ifsc + ", branch=" + branch + ", accountType="
				+ accountType + ", balance=" + balance + "]";
	}
	
}
