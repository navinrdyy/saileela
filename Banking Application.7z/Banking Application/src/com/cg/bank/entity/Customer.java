package com.cg.bank.entity;

public class Customer {

	private String name;
	private String address;
	private long accountNo;
	private String phoneno;
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Customer(String name, String address, long accountNo, String phoneno) {
		super();
		this.name = name;
		this.address = address;
		this.accountNo = accountNo;
		this.phoneno = phoneno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountN0) {
		this.accountNo = accountNo;
	}
	public String getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}
	@Override
	public String toString() {
		return "Customer [name=" + name + ", address=" + address + ", accountNumber=" + accountNo + ", phoneno="
				+ phoneno + "]";
	}
	

}
