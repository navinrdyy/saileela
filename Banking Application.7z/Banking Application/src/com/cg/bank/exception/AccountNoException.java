package com.cg.bank.exception;

public class AccountNoException extends Exception{

	public AccountNoException() {
		super("Enter valid account number");
		
	}

	

}
