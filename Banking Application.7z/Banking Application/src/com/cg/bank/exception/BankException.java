package com.cg.bank.exception;

public class BankException extends Exception{

	public BankException(String message) {
		super("wrong format enter valid one");
		
	}

	

}
