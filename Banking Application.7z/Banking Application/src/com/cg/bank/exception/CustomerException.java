package com.cg.bank.exception;

public class CustomerException extends Exception {

	public CustomerException() {
		super("Wrong format.Enter valid one.");
		
	}

	
}
