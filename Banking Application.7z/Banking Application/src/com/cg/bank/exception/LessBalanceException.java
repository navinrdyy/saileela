package com.cg.bank.exception;

public class LessBalanceException extends Exception {

	public LessBalanceException() {
		super("Enter amount with minimum balance 3000");
		
	}

	

}
