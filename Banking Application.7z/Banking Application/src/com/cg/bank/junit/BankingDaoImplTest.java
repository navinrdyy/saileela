package com.cg.bank.junit;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.cg.bank.dao.BankingDaoImpl;
import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;
import com.cg.bank.exception.BankException;


class BankingDaoImplTest {
static BankingDaoImpl bdao=new BankingDaoImpl();

	@Test
	public void testShowBalance() throws BankException {
	assertEquals(15000,bdao.showBalance(1234567890));
	}
	
	@Test
	public void testDeposit() throws BankException{
		assertEquals(18000, bdao.deposit(1234567890)+3000);
	}
	
	@Test
	public void testWithdraw() throws BankException{
		assertEquals(13000, bdao.deposit(1234567890)-2000);
	}
	
	@Test
	public void testFundTransfer() throws BankException{
		assertEquals(13000, bdao.deposit(1234567890)-2000);
		assertEquals(30000,bdao.fundTransfer(1234567891)+2000);
	}
	
}
