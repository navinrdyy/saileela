package com.cg.bank.service;

import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.bank.dao.BankingDaoImpl;
import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;
import com.cg.bank.exception.BankException;
import com.cg.bank.util.Bank_Entry;

public class BankingServiceImpl implements BankingService {
 BankingDaoImpl dao= new BankingDaoImpl();
 
	
	
	
	@Override
	public HashMap<Long, Customer> createAccount(Account a, Customer c) throws BankException {
		HashMap<Long,Customer> hc= dao.createAccount(a,c);
		return hc;
	}
	@Override
	public double showBalance(long accountNo) {
		// TODO Auto-generated method stub
		return dao.showBalance(accountNo);
	}
	@Override
	public double deposit(long accountNo) {
		// TODO Auto-generated method stub
		return dao.deposit(accountNo);
	}
	@Override
	public double withdraw(long accountNo) {
		// TODO Auto-generated method stub
		return dao.withdraw(accountNo);
	}
	@Override
	public double fundTransfer(long accountNo) {
		// TODO Auto-generated method stub
		return dao.fundTransfer(accountNo);
	}
	@Override
	public void printTransaction() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public boolean Validatename(String CustomerName) throws BankException {
		Pattern p=Pattern.compile("^[A-Z]{1}[a-z]{3,15}");
		Matcher m=p.matcher(CustomerName);
		if(m.matches()) {
			return true;
		}
		return false;
		
	}
	@Override
	public boolean Validatenumber(String mobileno) throws BankException {
		
		Pattern p=Pattern.compile("[0-9]{10}");
		Matcher m=p.matcher(mobileno);
		if(m.matches()) {
			return true;
		}
		return false;
	}
	public Account getaccountdetails(long accountnumber) {
	
		return dao.getaccountdetails(accountnumber);
	}
	
}
