package com.cg.bank.ui;

import java.util.HashMap;
import java.util.Scanner;

import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;
import com.cg.bank.exception.AccountNoException;
import com.cg.bank.exception.BankException;
import com.cg.bank.exception.CustomerException;
import com.cg.bank.exception.LessBalanceException;
import com.cg.bank.service.BankingServiceImpl;
import com.cg.bank.util.Bank_Entry;




public class Client {
	static Scanner sc=null;
	static BankingServiceImpl bService=null;
	public static void main(String[] args) throws BankException {
		sc=new Scanner(System.in);
		bService= new BankingServiceImpl();
		int choice=0;
		while(true)
		{
			System.out.println("Wlecome to ABC Bank\n");
			System.out.println("Select option\n");
			System.out.println("1.Create Account\n");
			System.out.println("2.Show Balance\n");
			System.out.println("3: Deposit\n");
			System.out.println("4.Withdraw\n");
			System.out.println("5.Fund Transfer\n");
			System.out.println("6.Print transaction\n");
			System.out.println("7.Exit");
	choice=sc.nextInt();
	switch(choice)
	{
	case 1:
		createAccount();
		break;
	case 2:  showBalance();
	       break;
	case 3: deposit();
	        break;
	case 4:withdraw();
	        break;
	case 5:
		fundTransfer();
	       break;
	case 6: printTransaction();
	        break;	        
	case 7:	System.exit(0);
	       break;
		default: System.out.println("Enter valid option");


	}
		}
	}
	private static void createAccount() throws BankException  {
	
			System.out.println("Enter your name:");
			String name = sc.next();
			if(bService.Validatename(name)) {
					 {
						
					System.out.println("Enter mobile number:");
					String num=sc.next();
		
					
						if(bService.Validatenumber(num)) {  
				
				
							System.out.println("Enter your address:");
							String address= sc.next();
							System.out.println("Select account type");
							System.out.println("1.savings");
							System.out.println("2.current");
							int acc=sc.nextInt();
							switch (acc) {
							case 1:
								System.out.println("Enter amount to be added for your new account:");
								double balance=sc.nextDouble();
								if(balance>3000)
								{
									System.out.println("Enter the branch to create account:");
							String branch=sc.next();
							long accountno=(long)(Math.round(Math.random()*999999999));
									String ifsc=getifsc(branch);
									Customer c=new Customer( name, address, accountno,num);
									Account b=new Account(accountno,ifsc,branch, "savings",balance);
									HashMap<Long, Customer> hc=Bank_Entry.createAccount(b, c);
									System.out.println(b);
									System.out.println(hc);
									break;
								}
								else
								{
									try {
										throw new LessBalanceException();
									} catch (LessBalanceException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
								}
								break;
							case 2:
								System.out.println("Enter amount to be added for new account:");
								double balance1=sc.nextDouble();
								if(balance1>=0)
								{
									System.out.println("Enter branch to create account:");
									String branch=sc.next();
									long accountno=(long)(Math.round(Math.random()*999999999));
									String ifsc=getifsc(branch);
									Customer c=new Customer(name, address, accountno,num);
									Account b=new Account(accountno,ifsc,branch, "current",balance1);
									HashMap<Long, Customer> hc=Bank_Entry.createAccount(b, c);
									System.out.println(b);
									System.out.println(hc);
									break;
								}
								break;
						default:
								System.err.println("Enter valid account type ( Savings/Current)");
								break;
							}
							}
							else
								try {
									throw new CustomerException();
								} catch (CustomerException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
					}
						
					 
					}
			else
			{
				try {
					throw new CustomerException();
				} catch (CustomerException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
					
				
			}
	public static void showBalance() {

		System.out.println("Enter account number to see your balance");
		long accountnumber=sc.nextInt();
		
		Account bd= bService.getaccountdetails(accountnumber);
		if(bd!=null)
		{
		double accbalance=showBalance(accountnumber);
		System.out.println("Account balance for entered account number is:"+accbalance);
		System.out.println(" Do you want Transaction receipt?");
		System.out.println("1.yes");
		System.out.println("2.no");
		int n=sc.nextInt();
		switch (n)
		{
		case 1:
	System.out.println(bd);
	break;
		case 2:
			System.exit(0);
			break;
		
		}
		
	} else
			try {
				throw new AccountNoException ();
			} catch (AccountNoException  e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

	}
	public static double showBalance(long accountNo) {
		double d;
		Bank_Entry b=new Bank_Entry() ;
		d=b.showBalance(accountNo);
		return d;
	}
	public static void deposit()
	{
		System.out.println("Enter account number to view your balance:");
		long accountnumber=sc.nextInt();
		Account bd=bService.getaccountdetails(accountnumber);
		if(bd!=null)
		{
		double accbalance=showBalance(accountnumber);
		System.out.println("Enter amount to  deposit:");
		double amt=sc.nextDouble();
		double totalamount=amt+accbalance;
		System.out.println("Balance:"+totalamount);
		System.out.println("Do you want to print your transaction slip?");
		System.out.println("1.yes");
		System.out.println("2.no");
		int n=sc.nextInt();
		switch (n)
		{
		case 1:
			System.out.println("Account Number:"+accountnumber);
			System.out.println("Your Balance before transaction:"+" "+accbalance);
			System.out.println("Your Balance after transaction"+" "+totalamount);
			break;
		case 2:
			System.exit(0);
			break;
		}
		
		
	}
		else
			try {
				throw new AccountNoException();
			} catch (AccountNoException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

	

public static void withdraw()
{
	System.out.println("Enter account number to view balance");
	long accountnumber=sc.nextInt();
	Account bd=bService.getaccountdetails(accountnumber);
	if(bd!=null)
	{
	double accbalance=showBalance(accountnumber);
	System.out.println("Enter the amount to be withdrwan:");
	double amt=sc.nextDouble();
	if(accbalance>amt)
	{
	double totalamount=accbalance-amt;
	System.out.println("Your account balance after withdrawing:"+totalamount);
	System.out.println("\"Do you want to print your transaction slip?");
	System.out.println("1.yes");
	System.out.println("2.no");
	int n=sc.nextInt();
	switch (n) {
	case 1:
		System.out.println("Account Number:"+accountnumber);
		System.out.println("Your account balance  before transaction:"+"  "+accbalance+" and after transaction:"  +totalamount);
		
		break;
	case 2:
		System.exit(0);
		break;
	}
	
	}
	
	else
	{
		try {
			throw new LessBalanceException();
		} catch (LessBalanceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	} else
		try {
			throw new AccountNoException();
		} catch (AccountNoException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
}
public static void fundTransfer()
{
	System.out.println("Enter  account number:");
	long accountnumber=sc.nextInt();
	Account bd=bService.getaccountdetails(accountnumber);
	if(bd!=null)
	{
	double accbalance=showBalance(accountnumber);
	System.out.println("Enter  account number to whom you want to transfer:");
	long accountnumber1=sc.nextInt();
	Account bd1=bService.getaccountdetails(accountnumber1);
	if(bd1!=null)
	{
	double accbalance1=showBalance(accountnumber1);
	System.out.println("Enter the amount to be transfered:");
	double amt=sc.nextDouble();
	if(amt<accbalance)
	{
	double amount=accbalance-amt;
	double amount1=accbalance1+amt;
	String acctype=getaccounttype(accountnumber);
	String acctype1=getaccounttype(accountnumber1);
	String ifsc=getifsccode(accountnumber);
	String ifsc1=getifsccode(accountnumber1);
	String branch=getbranch(accountnumber);
	String branch1=getbranch(accountnumber1);
	Account b=new Account(accountnumber, ifsc,branch ,acctype, amount);
	Account b1=new Account(accountnumber1, ifsc1,branch1, acctype1,amount1);
	System.out.println(" "+amt +" is transerferd to account "+accountnumber1 +" from the account number"+" "+accountnumber);
	System.out.println(b);
	System.out.println(b1);
	System.out.println("Do you want transaction slip?");
	System.out.println("1.yes");
	System.out.println("2.no");
	int n=sc.nextInt();
	switch (n)
	{
	case 1:
		System.out.println(" "+amt+" is transerferd to account "+accountnumber1 +" from the account"+" "+accountnumber );
		break;
	case 2:
	System.exit(0);
	break;
	}
	
} else
		try {
			throw new LessBalanceException();
		} catch (LessBalanceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	} else
		try {
			throw new AccountNoException ();
		} catch (AccountNoException  e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
} else
		try {
			throw new AccountNoException ();
		} catch (AccountNoException  e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
}
public static String getaccounttype(long accountnumber)
{
	String d;
	Bank_Entry be= new Bank_Entry();
	d=be.getaccounttype(accountnumber);
	return d;
}
public static String getifsccode(long accountnumber)
{
	String d;
	Bank_Entry be= new Bank_Entry();
	d=be.getifsccode(accountnumber);
	return d;
}
public static String getbranch(long accountnumber)
{
	String d;
	Bank_Entry be= new Bank_Entry();
	d=be.getbranch(accountnumber);
	return d;
}
public static String getifsc(String branch)
{
	String d;
	Bank_Entry be= new Bank_Entry();
	d=be.getbranch1(branch);
	return d;
}
public static void printTransaction()
{
	System.out.println("Do you want to print transaction slip?");
	System.out.println("1.yes");
	System.out.println("2.no");
	int n=sc.nextInt();
	switch (n)
	{
	case 1:
System.out.println("Enter your account number:");
long accountnumber=sc.nextInt();
Account bd=bService.getaccountdetails(accountnumber);
if(bd!=null)
{
	Account  b=Bank_Entry.getaccountdetails(accountnumber);
System.out.println(b);
} else
	try {
		throw new AccountNoException();
	} catch (AccountNoException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		break;
	case 2:
	System.exit(0);
	break;
	}
}
	
}

