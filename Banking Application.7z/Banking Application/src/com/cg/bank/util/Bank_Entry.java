package com.cg.bank.util;

import java.time.LocalDate;
import java.time.Month;
import java.util.HashMap;

import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;



public class Bank_Entry {

	private static HashMap<Long,Account> amap=new HashMap<Long,Account>();
	
	static {
	amap.put((long) 1234567890,new Account(1234567890,"abc12345","Chennai","savings",15000));
	amap.put((long)1234567891,new Account(1234567891,"abc13345","Bengaluru","current",28000));
	amap.put((long)1234567892,new Account(1234567892,"abc12245","Hyderabad","current",45000));
	amap.put((long)1234567893,new Account(1234567893,"abc19345","Pune","savings",65000));
}
	
private static HashMap<Long,Customer> cmap=new HashMap<Long,Customer>();
	
	static {
	cmap.put((long) 1234567890,new Customer("Aish","Chennai",1234567890,"9840927463"));
	cmap.put((long)1234567891,new Customer("Ajay","Bengaluru",1234567891,"9849927463"));
	cmap.put((long)1234567892,new Customer("Sowjanya","Hyderabad",1234567892,"9840927653"));
	cmap.put((long)1234567893,new Customer("Alia","Pune",1234567893,"9840921234"));
}

private static HashMap<String,String> imap=new HashMap<String,String>();
	
	static {
	imap.put("Chennai", "abc12345");
	imap.put("Bengaluru", "abc13345");
	imap.put("Hyderabad", "abc12245");
	imap.put("Pune", "abc19345");
	
}


	public static HashMap<Long, Customer> createAccount(Account a, Customer c) {
		amap.put(a.getAccountNo(), a);
		cmap.put(c.getAccountNo(), c);
		return cmap;
	}
	public static double showBalance(long accountNo) {
		Account acc=amap.get(accountNo);
		return acc.getBalance();
	}
	public double deposit(long accountNo) {
		Account acc=amap.get(accountNo);
		return acc.getBalance();
	}
	public double withdraw(long accountNo) {
		Account acc=amap.get(accountNo);
		return acc.getBalance();
	}
	public double fundTransfer(long accountNo) {
		Account acc=amap.get(accountNo);
		return acc.getBalance();
	}
	public static String getaccounttype(long accountnumber) {
		Account bd=amap.get(accountnumber);
		return bd.getAccountType();
		
	}
	public static String getifsccode(long accountnumber) {
		Account bd=amap.get(accountnumber);
		return bd.getIfsc();
		
	}
	public static String getbranch(long accountnumber) {
		Account bd=amap.get(accountnumber);
		return bd.getBranch();
		
	}
	public String getbranch1(String branch) {
		// TODO Auto-generated method stub
		String s=imap.get(branch);
		return s;
	}
	public static Account getaccountdetails(long accountnumber) {
		// TODO Auto-generated method stub
		Account b=amap.get(accountnumber);
		return b;
	}
	public static HashMap<Long, Account> add(Account d) {
		// TODO Auto-generated method stub
		amap.put(d.getAccountNo(), d);
		return amap;
	}

}
