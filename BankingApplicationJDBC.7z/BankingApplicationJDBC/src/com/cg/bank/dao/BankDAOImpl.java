package com.cg.bank.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;

import com.cg.bank.util.DatabaseConnection;

public class BankDAOImpl implements BankDAO {

	

	@Override
	public Account showBalance(long accountNo) throws ClassNotFoundException, SQLException {
		Connection con=DatabaseConnection.connect();
		Statement stmt =con.createStatement();
		ResultSet res =stmt.executeQuery("select * from Account_Details where ACCOUNT_NO ='"+accountNo+" ' ");
		while(res.next()){
			long accountnum=res.getLong(1);
			String accounttype=res.getString(2);
			double balance=res.getDouble(3);
			Account ac=new Account(accountnum,accounttype,balance);
			return ac;
		}
		
		return null;
	}

	@Override
	public Account deposit(Account a) throws ClassNotFoundException, SQLException {
		Connection con=DatabaseConnection.connect();
		Statement stmt =con.createStatement();
		ResultSet res =stmt.executeQuery("update Account_Details set ACCOUNT_BALANCE='"+a.getBalance()+"'where ACCOUNT_NO='"+a.getAccountNo()+"'");
		return null;
	}

	@Override
	public Account withdraw(Account a) throws ClassNotFoundException, SQLException {
		Connection con=DatabaseConnection.connect();
		Statement stmt =con.createStatement();
		ResultSet res =stmt.executeQuery("update Account_Details set ACCOUNT_BALANCE='"+a.getBalance()+"'where ACCOUNT_NO='"+a.getAccountNo()+"'");
		return null;
	}

	@Override
	public Account fundTransfer(Account a) throws ClassNotFoundException, SQLException {
		Connection con=DatabaseConnection.connect();
		Statement stmt =con.createStatement();
		ResultSet res =stmt.executeQuery("update Account_Details set ACCOUNT_BALANCE='"+a.getBalance()+"'where ACCOUNT_NO='"+a.getAccountNo()+"'");
		return null;
	}

	@Override
	public void addCustomer(Customer c)throws ClassNotFoundException, SQLException  {
		Connection con=DatabaseConnection.connect();
		Statement stmt =con.createStatement();
		PreparedStatement pst =con.prepareStatement("INSERT INTO Customer_Details VALUES(?,?,?,?)");
		pst.setLong(1, c.getAccountNo());
		pst.setString(2, c.getName());
		pst.setString(3, c.getAddress());
		pst.setString(4, c.getPhoneno());
		pst.executeUpdate();
	}

	@Override
	public void addAccount(Account a) throws ClassNotFoundException, SQLException {
		Connection con=DatabaseConnection.connect();
		Statement stmt =con.createStatement();
		PreparedStatement pst =con.prepareStatement("INSERT INTO Account_Details VALUES(?,?,?)");
		pst.setLong(1, a.getAccountNo());
		pst.setString(2, a.getAccountType());
		pst.setDouble(3, a.getBalance());
		pst.executeUpdate();
		
	}

}
