package com.cg.bank.entity;

public class Customer {
	private long accountNo;
	private String name;
	private String address;
   private String phoneno;
public long getAccountNo() {
	return accountNo;
}
public void setAccountNo(long accountno2) {
	this.accountNo = accountno2;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getPhoneno() {
	return phoneno;
}
public void setPhoneno(String phoneno) {
	this.phoneno = phoneno;
}
public Customer(long accountNo, String name, String address, String phoneno) {
	super();
	this.accountNo = accountNo;
	this.name = name;
	this.address = address;
	this.phoneno = phoneno;
}
public Customer() {
	super();
	// TODO Auto-generated constructor stub
}
@Override
public String toString() {
	return "Customer [accountNo=" + accountNo + ", name=" + name + ", address=" + address + ", phoneno=" + phoneno
			+ "]";
}
   
}
