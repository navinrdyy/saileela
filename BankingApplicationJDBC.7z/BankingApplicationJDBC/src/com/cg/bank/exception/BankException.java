package com.cg.bank.exception;

public class BankException extends Exception {

	public BankException() {
		super("wrong format enter valid one");
		// TODO Auto-generated constructor stub
	}

}
