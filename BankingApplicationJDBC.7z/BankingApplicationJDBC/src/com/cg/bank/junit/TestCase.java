package com.cg.bank.junit;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.SQLException;

import org.junit.jupiter.api.Test;

import com.cg.bank.dao.BankDAOImpl;
import com.cg.bank.exception.BankException;

class TestCase {
	static BankDAOImpl bdao=new BankDAOImpl();
	@Test
	public void testShowBalance() throws BankException, ClassNotFoundException, SQLException {
		assertEquals(15000,bdao.showBalance(1234567890));
		}


}
