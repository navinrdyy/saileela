package com.cg.bank.service;

import java.sql.SQLException;

import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;
import com.cg.bank.exception.BankException;


public interface BankService {
	public void addCustomer(Customer c) throws ClassNotFoundException, SQLException  ;
	public void addAccount(Account a) throws ClassNotFoundException, SQLException ;
	public Account showBalance(long accountNo) throws ClassNotFoundException, SQLException;
	public Account deposit(Account a) throws ClassNotFoundException, SQLException;
	public Account withdraw(Account a) throws ClassNotFoundException, SQLException;
	public Account fundTransfer(Account a) throws ClassNotFoundException, SQLException;;
	public boolean  Validatename(String CustomerName) throws BankException;
	public boolean Validatenumber(String mobileno) throws BankException;
}
 