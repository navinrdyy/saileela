package com.cg.bank.service;

import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.bank.dao.BankDAO;
import com.cg.bank.dao.BankDAOImpl;
import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;
import com.cg.bank.exception.BankException;

public class BankServiceImpl implements BankService {
	BankDAO dao= new BankDAOImpl ();

	@Override
	public void addCustomer(Customer c) throws ClassNotFoundException, SQLException  {
	 dao.addCustomer(c);

	}

	@Override
	public void addAccount(Account a) throws ClassNotFoundException, SQLException  {
     dao.addAccount(a);

		
	}

	@Override
	public Account showBalance(long accountNo) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Account acc=dao.showBalance(accountNo);
		return acc;
		
	}

	@Override
	public Account deposit(Account a) throws ClassNotFoundException, SQLException {
		Account acc=dao.deposit(a);
		return acc;
	}

	@Override
	public Account withdraw(Account a)throws ClassNotFoundException, SQLException {
		Account acc=dao.withdraw(a);
		return acc;
	}

	@Override
	public Account fundTransfer(Account a)throws ClassNotFoundException, SQLException {
		Account acc=dao.fundTransfer(a);
		return acc;
	}

	@Override
	public boolean Validatename(String CustomerName) throws BankException {
		Pattern p=Pattern.compile("^[A-Z]{1}[a-z]{3,15}");
		Matcher m=p.matcher(CustomerName);
		if(m.matches()) {
			return true;
		}
		return false;	
		
	}

	@Override
	public boolean Validatenumber(String mobileno) throws BankException {
		Pattern p=Pattern.compile("[0-9]{10}");
		Matcher m=p.matcher(mobileno);
		if(m.matches()) {
			return true;
		}
		return false;
	}
}
