package com.cg.bank.ui;

import java.sql.SQLException;
import java.util.Scanner;

import com.cg.bank.entity.Account;
import com.cg.bank.entity.Customer;
import com.cg.bank.exception.AccountNoException;
import com.cg.bank.exception.BankException;
import com.cg.bank.exception.CustomerException;
import com.cg.bank.exception.LessBalanceException;
import com.cg.bank.service.BankServiceImpl;

public class Client {

	static Scanner sc=null;
	static BankServiceImpl bService=null;
	public static void main(String[] args) throws BankException, ClassNotFoundException, SQLException {
		sc=new Scanner(System.in);
		bService= new BankServiceImpl();
		int choice=0;
		while(true)
		{
			System.out.println("Welcome to ABC Bank\n");
			System.out.println("Select option\n");
			System.out.println("1.Create Account\n");
			System.out.println("2.Show Balance\n");
			System.out.println("3: Deposit\n");
			System.out.println("4.Withdraw\n");
			System.out.println("5.Fund Transfer\n");
		    System.out.println("6.Exit");
	choice=sc.nextInt();
	switch(choice)
	{
	case 1:
		createAccount();
		break;
	case 2:  showBalance();
	      break;
	case 3: deposit();
	       break;
	case 4:withdraw();
	        break;
	case 5:
		fundTransfer();
	      break;	        
	case 6:	System.exit(0);
	       break;
		default: System.out.println("Enter valid option");
	}
		}
	}
	private static void createAccount() throws BankException, ClassNotFoundException, SQLException {
		System.out.println("Enter your name:");
		String name = sc.next();
		if(bService.Validatename(name)) {
				 {
					
				System.out.println("Enter mobile number:");
				String num=sc.next();
	
				
					if(bService.Validatenumber(num)) {  
			
			
						System.out.println("Enter your address:");
						String address= sc.next();
						System.out.println("Select account type");
						System.out.println("1.savings");
						System.out.println("2.current");
						int acc=sc.nextInt();
						switch (acc) {
						case 1:
							System.out.println("Enter amount to be added for your new account:");
							double balance=sc.nextDouble();
							if(balance>3000)
							{
								
								long accountno=(long)(Math.round(Math.random()*999999999));
								System.out.println("Your account is created\n");
								System.out.println("Your account number: " +accountno);
								Account b=new Account(accountno,"savings",balance);
								bService.addAccount(b);
								Customer c=new Customer(accountno,name,address,num);
								bService.addCustomer(c);
								break;
							}
							else
							{
								try {
									throw new LessBalanceException();
								} catch (LessBalanceException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							}
							break;
						case 2:
							System.out.println("Enter amount to be added for new account:");
							double balance1=sc.nextDouble();
							if(balance1>=0)
							{
								
								long accountno=(long)(Math.round(Math.random()*999999999));
								System.out.println("Your account is created\n");
								System.out.println("Your account number: " +accountno);
								Account b=new Account(accountno,"current",balance1);
								bService.addAccount(b);
								Customer c=new Customer(accountno,name,address,num);
								bService.addCustomer(c);
								break;
							}
							break;
					default:
							System.err.println("Enter valid account type ( Savings/Current)");
							break;
						}
						}
						else
							try {
								throw new CustomerException();
							} catch (CustomerException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
				}
					
				 
				}
		else
		{
			try {
				throw new CustomerException();
			} catch (CustomerException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
					
		
	}
	private static void showBalance() throws ClassNotFoundException, SQLException {
		System.out.println("Enter account number to view balance");
		long accountnumber=sc.nextInt();
	Account a=bService.showBalance(accountnumber);
	if(a!=null) {
		double bal=a.getBalance();
		System.out.println("Your balance: " +bal);}
		else
		{
			try {
				throw new AccountNoException();
			}catch (AccountNoException e) {
				e.printStackTrace();
			}
		}
		
	}
	private static void deposit() throws ClassNotFoundException, SQLException {
		System.out.println("Enter account number to view balance");
		long accountnumber=sc.nextInt();
		Account a=bService.showBalance(accountnumber);
		if(a!=null) {
		double bal=a.getBalance();
		System.out.println("Enter amount to  deposit:");
		double amt=sc.nextDouble();
		double totalamount=amt+bal;
		Account ac=new Account(accountnumber,a.getAccountType(),totalamount);
		Account acc1=bService.deposit(ac);
		System.out.println(" Your balance after depositing:"+totalamount);}
		else
		{
			try {
			throw new AccountNoException();
		}catch (AccountNoException e) {
			e.printStackTrace();
		}
			
		}
		
	}
	private static void withdraw() throws ClassNotFoundException, SQLException {
		System.out.println("Enter account number to view balance");
		long accountnumber=sc.nextInt();
		Account a=bService.showBalance(accountnumber);
		if(a!=null) {
		double bal=a.getBalance();
		System.out.println("Enter amount to withdraw:");
		double amt=sc.nextDouble();
		double totalamount=bal-amt;
		Account ac=new Account(accountnumber,a.getAccountType(),totalamount);
		Account acc1=bService.withdraw(ac);
		System.out.println(" Your balance after withdrawing:"+totalamount);}
		else
		{
			try {
			throw new AccountNoException();
		}catch (AccountNoException e) {
			e.printStackTrace();
		}
		}
		
	}
	private static void fundTransfer() throws ClassNotFoundException, SQLException {
		System.out.println("Enter your account number");
		long accountnumber1=sc.nextInt();
		Account a=bService.showBalance(accountnumber1);
        System.out.println("Your balance Rs"+a.getBalance());
        double bal=a.getBalance();
		System.out.println("Enter account number where you want to transfer");
		long accountnumber2=sc.nextInt();
	    System.out.println("Enter amount to transfer");
		double amt=sc.nextDouble();
		double totalamount=bal-amt;
		a.setBalance(totalamount);
		Account acc1=new Account(accountnumber1,a.getAccountType(),totalamount);
		bService.withdraw(acc1);
		Account a1=bService.showBalance(accountnumber2);
		double bal1=a1.getBalance();
		double totalamt=bal1+amt;
		a1.setBalance(bal1);
		Account acc2=new Account(accountnumber2,a.getAccountType(),totalamt);
		bService.deposit(acc2);
		System.out.println("Your balance after fundtransfer:" +acc1.getBalance());
		System.out.println(acc1);
		
		
	}
	

}
