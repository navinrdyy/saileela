import java.util.*;
class Employee implements Comparable<Employee>{
	int id;
	String name;
	public Employee(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + "]";
	}
	
	@Override
	public int compareTo(Employee e) {
		
		return this.name.compareTo(e.name);
	}
			
}
public class EmployeeDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Employee> se=new ArrayList<Employee>();
		Employee e1=new Employee(1,"c");
		Employee e2=new Employee(2,"a");
		
		se.add(e1);
		se.add(e2);
		Collections.sort(se);
		System.out.println();
		
		/*Iterator<Employee> i=se.iterator();
		while(i.hasNext()) {
			//Employee e=new Employee(e);
			System.out.println(i.next());
		}*/
		for(Employee e:se)
			System.out.println(e);
	}

}
