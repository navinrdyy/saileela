import java.util.*;

public class MapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MapDemo md=new MapDemo();
		md.mapDemo();
	}
	
	/* Map: it is stand alone interface of collection interface
	 * HashMap, TreeMap, and LinkedHashMap are its Classes
	 * 
	 * it comes in <key,value> pair
	 * 
	 * HashMap returns value in any order where as TreeMap stores and returns in sorted
	 * order with respect to keys.
	 * 
	 * LinkedHashMap returns values as per insertion order
	 * 
	 * to read values from Map classes:
	 * 1. obj.keySet()
	 * 2. obj.values()
	 * 3. obj.entrySet()
	 * 
	 * 
	*/
	void mapDemo() {
		
	int sum=0;
		Map<String,Integer> hmap=new HashMap<String,Integer>();
	
		/**
		 * 
		 * Map<Integer,Employee> emap=new HashMap<Integer,Employee>();
		 * 
		 * Employee emp=new Employee();
		 * emp.setId(1);
		 * emp.setName("Roja");
		 * emp.setSalary(25000);
		 * 
		 * emap.put(emp.getId(),emp);
		 * 
		 * 
		 * 
		 * Employee emp1=new Employee();
		 * emp1.setId(2);
		 * emp1.setName("Jhansi");
		 * emp.setSalary(25000);
		 * 
		 * emap.put(emp.getId(),emp1);
		 * 
		 * 
		 * for(Object o:emap.entrySet()){
		 * 
		 * 	syso(o.getKey());
		 * syso(o.getValue());
		 * }
		 * 
		 * 
		 * for(Employe e:emap.Values()){
		 * 
		 * syso(e);
		 * }
		 * 
		 * 
		 * for(int i:emap.keySet()){
		 * 
		 * syso(i);
		 * 
		 * 
		 * }
		 * 
		 * 
		 * 
		 * 
		 * Employee e2=emap.get(3);
		 * 
		 * 
		 * 
		 */
		hmap.put("one", 1);
		hmap.put("two",2);
		hmap.put("three", 3);
		hmap.put("four",new Integer(4));
		hmap.put("five", 5);		//Autoboxing reading in int format but writing in Integer

		System.out.println("\nHashMap: ");
		
		for(Object o: hmap.entrySet()) {
			System.out.println(o);
		}
		
		for(Object o: hmap.values()) {
			System.out.println("djkfsd");
			System.out.println(o);
		}
		System.out.println("sdfasdf"+ hmap.get("one"));
		/*to get values using keys*/
		for(String o:hmap.keySet()) {
			System.out.println((hmap.get(o)));
			sum=sum+hmap.get(o);				//Unboxing(getting in Integer format but operating as premitive
		}
		System.out.println("Sum: "+sum);
		
		for(Map.Entry m:hmap.entrySet()){    
			System.out.println("Map.Entry m");
	           System.out.println(m.getKey()+" "+m.getValue());    
	          }  
		
		System.out.println("m.get()"+ hmap.get("five"));
		/*using iterator to get values using keys*/
		Iterator<String> i=hmap.keySet().iterator();
		while(i.hasNext()) {
			System.out.println(hmap.get(i.next()));
		}
	
		
		System.out.println(hmap.containsKey("one"));
		System.out.println(hmap.values());
		System.out.println(hmap.replace("one", 1 , 10));
		System.out.println(hmap.values());
		System.out.println(hmap.size());
		System.out.println(hmap.get("four"));
		System.out.println(hmap.remove("two"));
		System.out.println(hmap.values());
		
		TreeMap<String,Integer> tmap=new TreeMap<String,Integer>();
		tmap.putAll(hmap);
		System.out.println("\nTreeMap: ");                                                            
		for(Object o:tmap.entrySet()) {
			System.out.println(o);
		}
		
		LinkedHashMap<String,Integer> lhmap=new LinkedHashMap<String,Integer>();
		lhmap.putAll(hmap);
		System.out.println("\nLinkedHashMap: ");
		Iterator<Map.Entry<String, Integer>> a=lhmap.entrySet().iterator();
		while(a.hasNext()) {
			System.out.println(a.next());
		}
		
		lhmap.clear();
		System.out.println(lhmap.values());
	}

}
