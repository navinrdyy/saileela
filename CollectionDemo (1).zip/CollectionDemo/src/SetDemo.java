import java.util.*;

public class SetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		SetDemo sd=new SetDemo();
		sd.setDemo();
		
	}
	
	
/* Set: it is the sub interface of collection interface
 * HashSet, TreeSet, and LinkedHashSet are its Classes
 * 
 * Set allows no Duplicate
 * 
 * HashSet returns elements in any order whereas TreeSet returns elements in Sorted order
 * LinkedHashSet returns ordered elements that is it returns elements as per the insertion order
 * 
 * TreeSet uses binary tree for sorting.
 * 
 * Methods of Collection framework:
 * 
 * 
*/
	
	
	void setDemo() {
		HashSet<String> hset=new HashSet<String>();
		hset.add("java");
		hset.add("C");
		hset.add("C");
		hset.add("python");
		/*USE OF ENHANCED FOR LOOP*/
		for(Object o:hset) 
			System.out.println(o);
		
		
		TreeSet<String> tset=new TreeSet<String>();
		tset.addAll(hset);
		/*USE OF ITERATOR*/
		Iterator<String> i=tset.iterator();
		while(i.hasNext()) 
			System.out.println(i.next());
		
		
		LinkedHashSet<String> lhset=new LinkedHashSet<String>(hset);
		for (String string : lhset) 
			System.out.println(string);
		
	}
}
