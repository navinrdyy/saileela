package daoTest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import Exception.HOSException;
import dao.DaoClass;
import dao.DaoInterface;
import exception.PMSException;

public class DaoClassTest {
	DaoInterface daoImpl=null;

	@Before
	public void setUp() throws Exception {
		daoImpl=new DaoClass();
		
	}

	@After
	public void tearDown() throws Exception {
		daoImpl=null;
	}

	@Test
	public void testAddPatient() {
		try {
			int genId = daoImpl.addPatient(null);
			assert(genId);
		} catch (HOSException e) {

		}
	}
	private void assertnotNull(int genId) {
		// TODO Auto-generated method stub
		
	}
	
	@Test
	public void testAddPatientNull() {
	
		try {
			int genId = daoImpl.addPatient(null);
			assertnotNull(genId);
		} catch (HOSException e) {

	}
	}
	@Test
	public void testGetAllPatientdetails() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetPatientdetails() {
		fail("Not yet implemented");
	}

}
