package bean;


public class Hospital{
	private int patientId;
	private String patientName;
	private String doctorName;
	//private int doctorTiming;
	private double doctorFees;
	
	public Hospital() {
	}
	
	public Hospital(int patientId, String patientName, String doctorName) {
		
		this.patientId = patientId;
		this.patientName = patientName;
		this.doctorName = doctorName;
		//this.doctorTiming = doctorTiming;
	}
	public Hospital(int patientId, String patientName, String doctorName, double doctorFees) {
		super();
		this.patientId = patientId;
		this.patientName = patientName;
		this.doctorName = doctorName;
		//this.doctorTiming = doctorTiming;
		this.doctorFees = doctorFees;
	}
	
	public int getPatientId() {
		return patientId;
	}
	public void setPatientId(int id) {
		this.patientId = id;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public String getDoctorName() {
		return doctorName;
	}
	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}
	
	
	public double getDoctorFees() {
		return doctorFees;
	}
	public void setDoctorFees(double doctorFees) {
		this.doctorFees = doctorFees;
	}

	/*@Override
	public String toString() {
		return "Hospital [patientId=" + patientId + ", patientName =" + patientName + ",docterName=" + doctorName + ",doctorFees=" + doctorFees +"]";
	}*/
}