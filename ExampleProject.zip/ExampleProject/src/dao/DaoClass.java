package dao;

import java.util.HashMap;

import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import Exception.HOSException;
import bean.Hospital;

public class DaoClass implements DaoInterface {
	
	Map<Integer, Hospital> hm= new HashMap<Integer, Hospital>();
	Hospital hospital=new Hospital();
	int patientId;
	
	public	int addPatient(Hospital hospital) throws HOSException {
		
		int patientId = (int) (Math.random() * 1000);

		hospital.setPatientId(patientId);
		
		//System.out.println(id);
		hm.put(patientId,hospital);

		return patientId;
	}
	
	public Hospital getAllPatientdetails() throws HOSException 
	{
		Hospital hospital2 = null;
		boolean flag = false;
		
		Set<Integer> set = hm.keySet();
		
		for(int i : set)
		{
			if(i == patientId)
			{
				Hospital hospital3 = hm.get(i);
				int patientId = hospital2.getPatientId();
				
				hospital = hm.get(patientId);
				hospital2 = hm.get(i);
				break;
			}
			
			if(hospital2 == null)
			{
				throw new HOSException("No Patient present with this Id.");
			}
			
			return hospital2;
		}
		
		return null;
	}
	
	@Override
	public Hospital getPatientdetails(int patientId) throws HOSException{
		Hospital h=null;
		for(Hospital h1 : hm.values())
		{
			if(h1.getPatientId()==patientId) {
				h=h1;
				break;
			}
		}
		
		return h;
	}
		
}


