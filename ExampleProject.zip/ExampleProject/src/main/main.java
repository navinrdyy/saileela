package main;

import java.time.LocalDate;
import java.util.InputMismatchException;
import java.util.Map;
import java.util.Scanner;

import Exception.HOSException;
import bean.Hospital;
import dao.DaoClass;
import service.ServiceClass;
import service.ServiceInterface;

public class main {

public static void main(String[] args) throws HOSException {

		Scanner scanner = null;
		ServiceInterface service = new ServiceClass();
		Hospital hosp = new Hospital();
		String continueChoice = "";
		
		do {

			System.out.println("****** Hospital management System ******");
			System.out.println("1.Add Patient");
			System.out.println("2.Disply Patient");
			System.out.println("3.Exit");
			//System.out.println("Please select your choice from options : ");
			//int patientId = 0;
			int choice = 0;
			boolean choiceFlag = false;

			do {
				scanner = new Scanner(System.in);
				System.out.println("Enter your choice : ");
				try {
					choice = scanner.nextInt();
					choiceFlag = true;

					switch (choice) {

					case 1:

						String patientName = "";
						boolean patientNameFlag = false;

						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Patient Name");
							try {
								patientName = scanner.nextLine();
								service.validateName(patientName);
								hosp.setPatientName(patientName);
								patientNameFlag = true;
								break;
							} catch (HOSException e) {
								patientNameFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!patientNameFlag);

						double doctorFees = 0;
						boolean doctorFeesFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Doctor Fees : ");
							try {
								doctorFees = scanner.nextDouble();
								service.validateFees(doctorFees);
								hosp.setDoctorFees(doctorFees);
								doctorFeesFlag = true;
								break;
							} catch (InputMismatchException e) {
								doctorFeesFlag = false;
								System.err.println("Cost should be digits");
							} catch (HOSException e) {
								doctorFeesFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!doctorFeesFlag);

						String doctorName = "";
						boolean doctorNameFlag = false;

						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Doctor Name");
							try {
								doctorName = scanner.nextLine();
								service.validateName(doctorName);
								hosp.setDoctorName(doctorName);
								doctorNameFlag = true;
								break;
							} catch (HOSException e) {
								doctorNameFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!doctorNameFlag);

						
						//int doctorTiming=0;
						
						
						// Hospital hospital = new Hospital(patientId, patientName, doctorTiming, doctotFees);
						
						//hosp(patientId ,patientName,doctorName,doctorTiming, doctorFees);
						
						try {
							int patientId = service.addPatient(hosp);
							System.out.println("Your Patient Id : " + patientId);
						} catch (HOSException e) {
							System.err.println(e.getMessage());
						}

					break;

					case 2:
					{
						int patientId=0;
						boolean patientIdFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter your Patient Id : ");
							try {
								patientId = scanner.nextInt();
								service.validateId(patientId);
								patientIdFlag = true;
								break;
							} catch (InputMismatchException e) {
								patientIdFlag = false;
								System.err.println(e.getMessage());
							}
							catch (HOSException e) {
								System.err.println(e.getMessage());
							}
						} while (!patientIdFlag);

						try {
							Hospital hospital2= service.getPatientdetails(patientId);
							//DaoClass dao=new DaoClass();
							//hospital2=dao.getPatientdetails(patientId);
							System.out.println("Patient Id : "+hospital2.getPatientId()+", Patient Name : "+hospital2.getPatientName()+", Doctor Fees : "+hospital2.getDoctorFees()+", Doctor name : "+hospital2.getDoctorName());
							LocalDate localDate = LocalDate.now();
							System.out.println("Date : "+localDate);
						} catch (HOSException e) {
							System.err.println(e.getMessage());
						}

						break;
					}
					case 3:
						System.out.println("*** Thank You *** ");
						System.exit(0);
						break;

					default:
						choiceFlag = false;
						System.out.println("Input should be 1 or 2 or 3");
						break;
					}

				} catch (InputMismatchException e) {
					choiceFlag = false;
					System.err.println("please enter only digits");
				}

			} while (!choiceFlag);

			scanner = new Scanner(System.in);
			System.out.println("do you want to continue again [Yes/No]");
			continueChoice = scanner.nextLine();

		} while (continueChoice.equalsIgnoreCase("yes"));
		scanner.close();
	}
}
