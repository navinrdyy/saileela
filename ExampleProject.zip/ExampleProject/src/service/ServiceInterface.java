package service;

import Exception.HOSException;
import bean.Hospital;

public interface ServiceInterface {
	int addPatient(Hospital hospital) throws HOSException;
	public void validateName(String name) throws HOSException;
	public void valideteTiming(int timing) throws HOSException;
	public void validateFees(double doctorFees) throws HOSException;
	public Hospital getPatientdetails(int patientId) throws HOSException;
	void validateId(int patientId) throws HOSException;
	void validateTiming(int doctorTiming) throws HOSException;

}
