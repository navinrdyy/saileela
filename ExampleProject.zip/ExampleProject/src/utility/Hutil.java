package utility;

import java.util.HashMap;
import java.util.Map;

import bean.Hospital;

public class Hutil {
	private static Map<Integer,Hospital> hm=new HashMap<>();
	static
	{
		hm.put(null, new Hospital(101,"anu","doctorone",10,500));
		hm.put(null, new Hospital(102,"banu","doctortwo",10,500));
		hm.put(null, new Hospital(103,"kala","doctorthree",10,500));
		hm.put(null, new Hospital(104,"mala","doctorfour",10,500));
		
	}
	public static Map<Integer,Hospital>getMap()
	{
		return hm;
	}
	
	public static void setMap(Map<Integer,Hospital>hm)
	{
		Hutil.hm=hm;
	}
	}
