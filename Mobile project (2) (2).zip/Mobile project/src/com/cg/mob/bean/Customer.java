package com.cg.mob.bean;

public class Customer {
	private String customername;
	private String address;
	private String cellno;
	public String getCustomername() {
		return customername;
	}
	public void setCustomername(String customername) {
		this.customername = customername;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCellno() {
		return cellno;
	}
	public void setCellno(String cellno) {
		this.cellno = cellno;
	}
	@Override
	public String toString() {
		return "Customer [customername=" + customername + ", address="
				+ address + ", cellno=" + cellno + "]";
	}
	public Customer(String customername, String address, String cellno) {
		super();
		this.customername = customername;
		this.address = address;
		this.cellno = cellno;
	}
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
