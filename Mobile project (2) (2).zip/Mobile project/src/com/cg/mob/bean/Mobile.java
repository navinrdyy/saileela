package com.cg.mob.bean;



public class Mobile {
	private int orderid;
	private long customerid;
	private float totalprice;
	private String model;
	
	public int getOrderid() {
		return orderid;
	}
	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}
	public long getCustomerid() {
		return customerid;
	}
	public void setCustomerid(long customerid) {
		this.customerid = customerid;
	}
	public float getTotalprice() {
		return totalprice;
	}
	public void setTotalprice(float totalprice) {
		this.totalprice = totalprice;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	
	@Override
	public String toString() {
		return "Mobile [orderid=" + orderid + ", customerid=" + customerid
				+ ", totalprice=" + totalprice + ", model=" + model
				+ "]";
	}
	public Mobile() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Mobile(int orderid, long customerid, float totalprice, String model
			) {
		super();
		this.orderid = orderid;
		this.customerid = customerid;
		this.totalprice = totalprice;
		this.model = model;
		
	}
	

}
