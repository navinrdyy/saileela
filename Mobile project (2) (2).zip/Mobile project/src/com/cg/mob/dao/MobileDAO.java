package com.cg.mob.dao;

import java.util.HashMap;



import com.cg.mob.bean.Customer;
import com.cg.mob.bean.Mobile;

public interface MobileDAO {
public int purchasemobile(Integer i,Customer c);

public HashMap<String,Mobile> fetchAlldet();
	
	public Customer getpurchasedetails (int orderid);

}
