package com.cg.mob.dao;

import java.util.HashMap;

import com.cg.mob.bean.Customer;
import com.cg.mob.bean.Mobile;
import com.cg.mob.util.CollectionUtil;

public class MobileDAOImpl implements MobileDAO {

	@Override
	public int purchasemobile(Integer i,Customer c) {
		CollectionUtil.purchasemobile(i, c);
		return 0;
		
	}

	@Override
	public Customer getpurchasedetails(int orderid) {
		Customer mb2=CollectionUtil.getpurchasedetails(orderid);
		return mb2;
	}

	@Override
	public HashMap<String, Mobile> fetchAlldet() {
		HashMap<String, Mobile> mobmap=CollectionUtil.fetchalldet();
		return mobmap;
	}
	
	

}
