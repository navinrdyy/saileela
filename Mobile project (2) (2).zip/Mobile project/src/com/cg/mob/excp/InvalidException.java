package com.cg.mob.excp;

public class InvalidException extends Exception{

	public InvalidException(String arg0) {
		super(arg0);
		
	}
	

}
