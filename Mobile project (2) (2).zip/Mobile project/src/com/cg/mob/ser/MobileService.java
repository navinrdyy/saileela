package com.cg.mob.ser;


import java.util.HashMap;


import com.cg.mob.bean.Customer;
import com.cg.mob.bean.Mobile;
import com.cg.mob.excp.InvalidException;

public interface MobileService {
	public int purchasemobile(Integer i,Customer c);
	
	public Customer getpurchasedetails (int orderid);
	
	public HashMap<String,Mobile> fetchAlldet();
	
    public boolean validateCusName(String name) throws InvalidException;
	
	public boolean validateOrderID(String orderid) throws InvalidException;
	
	public boolean validateMobileNo(String cellno) throws InvalidException;

}
