package com.cg.mob.ser;


import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.mob.bean.Customer;
import com.cg.mob.bean.Mobile;
import com.cg.mob.dao.MobileDAO;
import com.cg.mob.dao.MobileDAOImpl;
import com.cg.mob.excp.InvalidException;

public class MobileServiceImpl implements MobileService {
	MobileDAO employeeDAO =new MobileDAOImpl();

	@Override
	public int purchasemobile(Integer i,Customer c) {
		employeeDAO.purchasemobile(i,c);
		return 0;
	}

	@Override
	public Customer getpurchasedetails(int orderid) {
		Customer mb1=employeeDAO.getpurchasedetails(orderid);
		return mb1;
	}

	@Override
	public boolean validateCusName(String name) throws InvalidException {
		Pattern  pattern =Pattern.compile("[A-Z]{1}[a-z]{3,15}");
		Matcher idMatch= pattern.matcher(name);
		if(idMatch.matches())
		{
			return true;
		}
	
		return false;
	}

	@Override
	public boolean validateOrderID(String orderid) throws InvalidException {
		
		return false;
	}

	@Override
	public boolean validateMobileNo(String cellno) throws InvalidException {
		Pattern pattern =Pattern.compile("[0-9]{10}");
		Matcher mobMatch= pattern.matcher(cellno);
		if(mobMatch.matches())
		{
			return true;
		}
		
		
		return false;
	}

	@Override
	public HashMap<String, Mobile> fetchAlldet() {
		HashMap<String, Mobile> mobmap=employeeDAO.fetchAlldet();
		return mobmap;
	}

}
