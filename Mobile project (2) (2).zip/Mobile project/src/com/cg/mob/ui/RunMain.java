package com.cg.mob.ui;


import java.util.HashMap;
import java.util.Random;
import java.util.Scanner;

import com.cg.mob.bean.Customer;
import com.cg.mob.bean.Mobile;
import com.cg.mob.excp.InvalidException;
import com.cg.mob.ser.MobileService;
import com.cg.mob.ser.MobileServiceImpl;

public class RunMain {

	static Scanner sc=null;
	static MobileService mobservice=null;
	
	public static void main(String[] args) throws InvalidException{
		while(true){
		sc=new Scanner(System.in);
		mobservice=new MobileServiceImpl();
		int choice=0;
		
		
		System.out.println("What do u want to do");
		System.out.println("1.Purchase Mobile");
		System.out.println("2.get purchasedetails");
		System.out.println("enter your choice");
		choice =sc.nextInt();
		switch(choice)
		{
		case 1:
			purchasemobile();
			break;
		case 2:
			getpurchasedetails();
			break;
		}
	}	
	}
	public static void purchasemobile() throws InvalidException{
		
	   
		Random rand = new Random(); 
		 
        int odid = rand.nextInt(10000000);
        
		System.out.println("Enter customer name:");
	    String name=sc.next();
	   boolean res= mobservice.validateCusName(name);
	    try
		{
			if(res==false)
			{
				throw new InvalidException("Invalid"); 
			}
				
				
			{
				
	    			System.out.println("Enter customer address:");
	    			String addrs=sc.next();
	    			
	    			
	    					System.out.println("Enter customer cellno:");
	    					String mobno=sc.next();
	    					 try
	 	    				{
	 	    					if(mobservice.validateMobileNo(mobno))
	 	    					{
	 	    						
	 	    							
	    					
	 	    						HashMap<String , Mobile> ff=mobservice.fetchAlldet();
	 	    						HashMap<String , Mobile> hs= new HashMap<String , Mobile>(ff);
	 	    						for (String ss: hs.keySet()){
	 	    							
	 	    							Mobile m=hs.get(ss);
	 	    							System.out.println("mobile model:"+m.getModel());
	 	    							System.out.println("mobile price:"+m.getTotalprice());
	 	    							
	 	    						}
	 	    						System.out.println("select the mobile brand");
	 	    						String model=sc.next();
	 	    						hs.get(model);
	 	    						System.out.println("   Purchase details   " );
	    					
	    					
	    					
	    					
	    					
	    					Customer customer =new Customer(name, addrs, mobno);
	    					mobservice.purchasemobile(odid, customer);
	    					System.out.println("MODEL:"+model);
	    					System.out.println("ORDER ID:"+odid);
	    					
	    					
	    					
	 	  
			}
	 	    				}catch(InvalidException ei){
	 	    					System.out.println("enter valid number");
	 	    				}
			
			}
		}catch(InvalidException e){
			System.out.println("enter the valid name");
		}
       
	}
	
	public static void getpurchasedetails(){
		System.out.println("Enter order ID:");
	    int orderid=sc.nextInt();
	    Customer mb3=mobservice.getpurchasedetails(orderid);
	    System.out.println(mb3);
	    
		
	}
	public static void fetchAlldet(){
		HashMap<String , Mobile> ff=mobservice.fetchAlldet();
		HashMap<String , Mobile> hs= new HashMap<String , Mobile>(ff);
		for (String ss: hs.keySet()){
			
			Mobile m=hs.get(ss);
			System.out.println("mobile model:"+m.getModel());
			System.out.println("mobile price:"+m.getTotalprice());
			
		}
		System.out.println("select the mobile brand");
		String model=sc.next();
		Mobile m=hs.get(model);
		System.out.println("The "+ model+" mobile is purchased with order id ");
	}
	
	
}
