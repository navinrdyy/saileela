package com.cg.mob.util;

import java.util.HashMap;




import com.cg.mob.bean.Customer;
import com.cg.mob.bean.Mobile;



public class CollectionUtil {
	private static HashMap<Integer,Customer> custmap =new HashMap<Integer,Customer>();
	static
	{
		custmap.put(1234, new Customer("Saravana", "madurai", "9443548885"));
	}
	private static HashMap<String,Mobile> mobmap =new HashMap<String,Mobile>();
	static
	{
		mobmap.put("Honor", new Mobile(1234,1000001, 20000.0f, "Honor"));
		mobmap.put("Apple", new Mobile(1234,1000002, 50000.0f, "Apple"));
		mobmap.put("Redmi", new Mobile(1234,1000003, 12000.0f, "Redmi"));
		mobmap.put("Samsung", new Mobile(1234,1000004, 18000.0f, "Samsung"));
	}
	
	public static void purchasemobile(Integer orderid,Customer cust){
		custmap.put(orderid, cust);
		System.out.println("NAME:"+cust.getCustomername());
		System.out.println("CITY:"+cust.getAddress());
		System.out.println("MOBILE:"+cust.getCellno());
		
	}
	
	
	public static Customer getpurchasedetails(int orderid){
		if(custmap.containsKey(orderid))
		{
			Customer mb=custmap.get(orderid);
			 return mb;
	}
		else{
		return null;}
}
	public static void  searchEmpByName(String s){
		
	}
	public static HashMap<String,Mobile> fetchalldet(){
		return mobmap;
	}
	
	
	}
	
