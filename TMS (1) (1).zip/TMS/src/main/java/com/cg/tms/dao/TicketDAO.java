package com.cg.tms.dao;
import java.util.HashMap;
import java.util.Map;
import com.cg.tms.dto.TicketBean;
public class TicketDAO
	{
	Map<Integer,String> ticketCategory = new HashMap<Integer,String>();
	Map<Integer,TicketBean> ticketLog = new HashMap<Integer,TicketBean>();
public TicketDAO() 
	{
		//Choose ticket category
		ticketCategory.put(1, "Software Installation");
		ticketCategory.put(2, "Mailbox Creation");
		ticketCategory.put(3, "Network Issues");
	}
	
	//Print all from category database 
public void getAllCategories()
	{
		for(Integer categoryID : ticketCategory.keySet())
		{
			String category = ticketCategory.get(categoryID);
			System.out.println(categoryID +" "+ category);	
		}
	}
public String getCategory(int categoryNumber) 
	{
		return ticketCategory.get(categoryNumber);	
	}
	
public void storeIntoTicketLog(int ticketNumber, TicketBean ticket) 
	{
		ticketLog.put(ticketNumber, ticket);
	}
	
public boolean checkTicketNumberALreadyExist(int ticketNumber)
	{
		if(ticketLog.containsKey(ticketNumber))
			return true;
		else
			return false;
	}

}
