package com.cg.tms.service;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import java.util.Scanner;
import java.util.function.Supplier;
import com.cg.tms.dto.TicketBean;
import com.cg.tms.dao.TicketDAO;
public class TicketService 
{
	TicketDAO db = new TicketDAO();
	Scanner input = new Scanner(System.in);
	TicketBean ticket = new TicketBean();
	Random random = new Random();
	int ticketNumber;
	int categoryNumber;
	String ticketDescription;
	int ticketPriorityNumber;
	String ticketPriority;
	Supplier<Integer> randomNumber = () -> 
	{
		return random.nextInt((9999 - 1000) + 1) + 1000;
	};
public void raiseTicket() 
	{
		ticketNumber = randomNumber.get();
		while(db.checkTicketNumberALreadyExist(ticketNumber))
		{
		ticketNumber = randomNumber.get();
		}	
		System.out.println("\nSelect Ticket Category from below List:\n");
		db.getAllCategories();
		
		//Get Category form the user
		System.out.print("\nEnter Option: ");
		categoryNumber = input.nextInt();
		if(categoryNumber >= 1 && categoryNumber <= 3)
		{
			ticket.setTicketCategoryId(db.getCategory(categoryNumber));
		}
		
		//Get the ticket description from the user
		System.out.println("\nEnter Description related to issue:");
		ticketDescription = input.next();
		ticket.setTicketDescription(ticketDescription);
		
		//Get the ticket priority from the user 
		System.out.print("\nEnter Priority [| 1.Low | 2.Medium | 3.High |]: ");
		ticketPriorityNumber = input.nextInt();
		
		if(ticketPriorityNumber == 1)
			ticketPriority = "Low";
		
		else if(ticketPriorityNumber == 2)
			ticketPriority = "Medium";
		
		else if(ticketPriorityNumber == 3)
			ticketPriority = "High";	
		ticket.setTicketPriority(ticketPriority);
		
		//Set the status of the ticket
		ticket.setTicketStatus("NEW");
		db.storeIntoTicketLog(ticketNumber, ticket);
		
		//Date format
		Date CurrentDate = new Date();
		DateFormat dateFormat = new SimpleDateFormat("dd MMMM yyyy hh:mm a"); 
		System.out.println("\n Ticket Number "+ ticketNumber + " logged Successfully at " + dateFormat.format(CurrentDate));
	}
}
