package com.cg.tms.ui;
import java.util.Scanner;
import com.cg.tms.service.TicketService;
public class MainUI
{
	public static void main(String[] args) 
	{
		TicketService ticketManagementSystem = new TicketService();
		Scanner input = new Scanner(System.in);
		
		while (true) 
		{
			System.out.println("XYZ Help Desk for Ticket Management System");
			System.out.println("1. Raise a Ticket");
			System.out.println("2. Exit from the System");
			
			System.out.print("\nEnter your choice: ");
			int userInput = input.nextInt();
			
			if(userInput == 1) 
			{
				ticketManagementSystem.raiseTicket(); 
				break;
			}
			
			else if(userInput == 2)
				break;
			
			else
				System.out.println("\nInvalid option!, Try sometimes later.\n");		
		}
	}
}
